/*
  dijkstra benchmark com instrumentacao perf_event_open
  Grupo 9 de 10 - Eventos: CYCLES + 0xD2 + 0xE0 + 0xE1 + 0xE2 + 0xE3 + 0xE4
  Gerado automaticamente para captura dos 57 eventos PMU do ARM Cortex-A53
*/
#define _GNU_SOURCE
#include <sched.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <string.h>
#include <sys/ioctl.h>
#include <linux/perf_event.h>
#include <linux/hw_breakpoint.h>
#include <asm/unistd.h>
#include <errno.h>
#include <stdint.h>
#include <inttypes.h>
#include <time.h>
#include "input.h"

/* ------------------------------------------------------------------ */
/*  Benchmark: dijkstra                                                */
/* ------------------------------------------------------------------ */
#define NONE        9999
#define OUT_OF_MEMORY -1
#define QUEUE_SIZE  1000

struct _NODE {
  int dist;
  int prev;
};

struct _QITEM {
  int node;
  int dist;
  int prev;
  struct _QITEM *next;
};

struct _NODE dijkstra_rgnNodes[ NUM_NODES ];
int dijkstra_queueCount;
int dijkstra_queueNext;
struct _QITEM *dijkstra_queueHead;
struct _QITEM dijkstra_queueItems[ QUEUE_SIZE ];
int dijkstra_checksum = 0;

int dijkstra_enqueue( int node, int dist, int prev ) {
  struct _QITEM *newItem = &dijkstra_queueItems[ dijkstra_queueNext ];
  struct _QITEM *last = dijkstra_queueHead;

  if ( ++dijkstra_queueNext >= QUEUE_SIZE )
    return OUT_OF_MEMORY;
  newItem->node = node;
  newItem->dist = dist;
  newItem->prev = prev;
  newItem->next = 0;

  if ( !last )
    dijkstra_queueHead = newItem;
  else {
    while ( last->next )
      last = last->next;
    last->next = newItem;
  }
  dijkstra_queueCount++;
  return 0;
}

void dijkstra_dequeue( int *node, int *dist, int *prev ) {
  if ( dijkstra_queueHead ) {
    *node = dijkstra_queueHead->node;
    *dist = dijkstra_queueHead->dist;
    *prev = dijkstra_queueHead->prev;
    dijkstra_queueHead = dijkstra_queueHead->next;
    dijkstra_queueCount--;
  }
}

int dijkstra_qcount( void ) {
  return ( dijkstra_queueCount );
}

int dijkstra_find( int chStart, int chEnd ) {
  int ch;
  int prev, node = 0;
  int cost, dist = 0;
  int i;

  for ( ch = 0; ch < NUM_NODES; ch++ ) {
    dijkstra_rgnNodes[ ch ].dist = NONE;
    dijkstra_rgnNodes[ ch ].prev = NONE;
  }

  if ( chStart != chEnd ) {
    dijkstra_rgnNodes[ chStart ].dist = 0;
    dijkstra_rgnNodes[ chStart ].prev = NONE;

    if ( dijkstra_enqueue( chStart, 0, NONE ) == OUT_OF_MEMORY )
      return OUT_OF_MEMORY;

    while ( dijkstra_qcount() > 0 ) {
      dijkstra_dequeue( &node, &dist, &prev );
      for ( i = 0; i < NUM_NODES; i++ ) {
        if ( ( cost = dijkstra_AdjMatrix[ node ][ i ] ) != NONE ) {
          if ( ( NONE == dijkstra_rgnNodes[ i ].dist ) ||
               ( dijkstra_rgnNodes[ i ].dist > ( cost + dist ) ) ) {
            dijkstra_rgnNodes[ i ].dist = dist + cost;
            dijkstra_rgnNodes[ i ].prev = node;
            if ( dijkstra_enqueue( i, dist + cost, node ) == OUT_OF_MEMORY )
              return OUT_OF_MEMORY;
          }
        }
      }
    }
  }
  return 0;
}

void dijkstra_init( void ) {
  int i, k;
  volatile int x = 0;
  for ( i = 0; i < NUM_NODES; i++ )
    for ( k = 0; k < NUM_NODES; k++ )
      dijkstra_AdjMatrix[ i ][ k ] ^= x;

  dijkstra_queueCount = 0;
  dijkstra_queueNext  = 0;
  dijkstra_queueHead  = ( struct _QITEM * )0;
  dijkstra_checksum   = 0;
}

void dijkstra_main( void ) {
  int i, j;
  for ( i = 0, j = NUM_NODES / 2; i < 20; i++, j++ ) {
    j = j % NUM_NODES;
    if ( dijkstra_find( i, j ) == OUT_OF_MEMORY ) {
      dijkstra_checksum += OUT_OF_MEMORY;
      return;
    } else
      dijkstra_checksum += dijkstra_rgnNodes[ j ].dist;
    dijkstra_queueNext = 0;
  }
}

/* ------------------------------------------------------------------ */
/*  Estrutura de leitura do perf                                       */
/* ------------------------------------------------------------------ */
struct read_format {
  uint64_t nr;
  struct {
    uint64_t value;
    uint64_t id;
  } values[];
};

/* ------------------------------------------------------------------ */
/*  Salva resultado no CSV                                             */
/* ------------------------------------------------------------------ */
void save_data(uint64_t val_cycles, uint64_t val_ev1, uint64_t val_ev2,
               uint64_t val_ev3, uint64_t val_ev4, uint64_t val_ev5, uint64_t val_ev6) {
  FILE *arq = fopen("saida_dijkstra_n_eventos.csv", "a");
  if (arq == NULL) { printf("ERROR OPEN FILE\n"); return; }
  fprintf(arq, "%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 " \n",
          val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6);
  fclose(arq);
}

/* ------------------------------------------------------------------ */
/*  Main                                                               */
/* ------------------------------------------------------------------ */
int main(int argc, char* argv[]) {

  struct perf_event_attr pea;
  int fd_cycles, fd_ev1, fd_ev2, fd_ev3, fd_ev4, fd_ev5, fd_ev6;
  uint64_t id_cycles, id_ev1, id_ev2, id_ev3, id_ev4, id_ev5, id_ev6;
  uint64_t val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6;
  char buf[4096];
  struct read_format* rf = (struct read_format*) buf;
  int i;

  /* Fixa o processo no CPU 0 */
  cpu_set_t set;
  CPU_ZERO(&set);
  CPU_SET(0, &set);
  sched_setaffinity(getpid(), sizeof(set), &set);

  /* ---------- Abre contador de ciclos (grupo lider) ---------- */
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_HARDWARE;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = PERF_COUNT_HW_CPU_CYCLES;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_cycles = syscall(__NR_perf_event_open, &pea, 0, -1, -1, 0);
  if (fd_cycles == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_cycles falhou: %s\n"
                    "Verifique: sudo sysctl -w kernel.perf_event_paranoid=0\n", strerror(errno));
    return 1;
  }
  ioctl(fd_cycles, PERF_EVENT_IOC_ID, &id_cycles);

  // 0xD2
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xD2;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev1 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev1 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev1 (0xD2) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev1, PERF_EVENT_IOC_ID, &id_ev1);

  // 0xE0
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xE0;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev2 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev2 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev2 (0xE0) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev2, PERF_EVENT_IOC_ID, &id_ev2);

  // 0xE1
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xE1;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev3 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev3 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev3 (0xE1) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev3, PERF_EVENT_IOC_ID, &id_ev3);

  // 0xE2
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xE2;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev4 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev4 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev4 (0xE2) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev4, PERF_EVENT_IOC_ID, &id_ev4);

  // 0xE3
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xE3;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev5 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev5 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev5 (0xE3) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev5, PERF_EVENT_IOC_ID, &id_ev5);

  // 0xE4
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xE4;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev6 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev6 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev6 (0xE4) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev6, PERF_EVENT_IOC_ID, &id_ev6);

  /* ---------- Inicializa o benchmark ---------- */
  dijkstra_init();

  /* ---------- Inicia contadores ---------- */
  ioctl(fd_cycles, PERF_EVENT_IOC_RESET,  PERF_IOC_FLAG_GROUP);
  ioctl(fd_cycles, PERF_EVENT_IOC_ENABLE, PERF_IOC_FLAG_GROUP);

  /* ---------- Executa benchmark ---------- */
  dijkstra_main();

  /* ---------- Para contadores ---------- */
  ioctl(fd_cycles, PERF_EVENT_IOC_DISABLE, PERF_IOC_FLAG_GROUP);

  /* ---------- Le resultados ---------- */
  read(fd_cycles, buf, sizeof(buf));
  for (i = 0; i < rf->nr; i++) {
    if      (rf->values[i].id == id_cycles) { val_cycles = rf->values[i].value; }
    else if (rf->values[i].id == id_ev1) { val_ev1 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev2) { val_ev2 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev3) { val_ev3 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev4) { val_ev4 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev5) { val_ev5 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev6) { val_ev6 = rf->values[i].value; }
  }

  save_data(val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6);

  /* ---------- Fecha descritores ---------- */
  close(fd_cycles);
  close(fd_ev1);
  close(fd_ev2);
  close(fd_ev3);
  close(fd_ev4);
  close(fd_ev5);
  close(fd_ev6);

  return 0;
}
