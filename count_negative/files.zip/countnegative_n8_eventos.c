/*
  countnegative benchmark com instrumentacao perf_event_open
  Grupo 8 de 10 - Eventos: CYCLES + 0xC9 + 0xCA + 0xCB + 0xCC + 0xD0 + 0xD1
  Gerado automaticamente para captura dos 57 eventos PMU do ARM Cortex-A53
*/
#define _GNU_SOURCE
#include <sched.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <string.h>
#include <sys/ioctl.h>
#include <linux/perf_event.h>
#include <linux/hw_breakpoint.h>
#include <asm/unistd.h>
#include <errno.h>
#include <stdint.h>
#include <inttypes.h>
#include <time.h>

/* ------------------------------------------------------------------ */
/*  Benchmark: countnegative                                           */
/* ------------------------------------------------------------------ */
#define MAXSIZE 20

typedef int matrix [ MAXSIZE ][ MAXSIZE ];

volatile int countnegative_seed;
matrix countnegative_array;
int countnegative_postotal, countnegative_negtotal;
int countnegative_poscnt, countnegative_negcnt;

void countnegative_initSeed( void ) {
  countnegative_seed = 0;
}

int countnegative_randomInteger( void ) {
  countnegative_seed = ( ( countnegative_seed * 133 ) + 81 ) % 8095;
  return countnegative_seed;
}

void countnegative_initialize( matrix Array ) {
  register int OuterIndex, InnerIndex;
  for ( OuterIndex = 0; OuterIndex < MAXSIZE; OuterIndex++ )
    for ( InnerIndex = 0; InnerIndex < MAXSIZE; InnerIndex++ )
      Array[ OuterIndex ][ InnerIndex ] = countnegative_randomInteger();
}

void countnegative_init( void ) {
  countnegative_initSeed();
  countnegative_initialize( countnegative_array );
}

void countnegative_sum( matrix Array ) {
  register int Outer, Inner;
  int Ptotal = 0;
  int Ntotal = 0;
  int Pcnt = 0;
  int Ncnt = 0;

  for ( Outer = 0; Outer < MAXSIZE; Outer++ )
    for ( Inner = 0; Inner < MAXSIZE; Inner++ )
      if ( Array[ Outer ][ Inner ] >= 0 ) {
        Ptotal += Array[ Outer ][ Inner ];
        Pcnt++;
      } else {
        Ntotal += Array[ Outer ][ Inner ];
        Ncnt++;
      }

  countnegative_postotal = Ptotal;
  countnegative_poscnt   = Pcnt;
  countnegative_negtotal = Ntotal;
  countnegative_negcnt   = Ncnt;
}

void countnegative_main( void ) {
  countnegative_sum( countnegative_array );
}

/* ------------------------------------------------------------------ */
/*  Estrutura de leitura do perf                                       */
/* ------------------------------------------------------------------ */
struct read_format {
  uint64_t nr;
  struct {
    uint64_t value;
    uint64_t id;
  } values[];
};

/* ------------------------------------------------------------------ */
/*  Salva resultado no CSV                                             */
/* ------------------------------------------------------------------ */
void save_data(uint64_t val_cycles, uint64_t val_ev1, uint64_t val_ev2,
               uint64_t val_ev3, uint64_t val_ev4, uint64_t val_ev5, uint64_t val_ev6) {
  FILE *arq = fopen("saida_countnegative_n_eventos.csv", "a");
  if (arq == NULL) { printf("ERROR OPEN FILE\n"); return; }
  fprintf(arq, "%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 " \n",
          val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6);
  fclose(arq);
}

/* ------------------------------------------------------------------ */
/*  Main                                                               */
/* ------------------------------------------------------------------ */
int main(int argc, char* argv[]) {

  struct perf_event_attr pea;
  int fd_cycles, fd_ev1, fd_ev2, fd_ev3, fd_ev4, fd_ev5, fd_ev6;
  uint64_t id_cycles, id_ev1, id_ev2, id_ev3, id_ev4, id_ev5, id_ev6;
  uint64_t val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6;
  char buf[4096];
  struct read_format* rf = (struct read_format*) buf;
  int i;

  /* Fixa o processo no CPU 0 */
  cpu_set_t set;
  CPU_ZERO(&set);
  CPU_SET(0, &set);
  sched_setaffinity(getpid(), sizeof(set), &set);

  /* ---------- Abre contador de ciclos (grupo lider) ---------- */
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_HARDWARE;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = PERF_COUNT_HW_CPU_CYCLES;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_cycles = syscall(__NR_perf_event_open, &pea, 0, -1, -1, 0);
  if (fd_cycles == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_cycles falhou: %s\n"
                    "Verifique: sudo sysctl -w kernel.perf_event_paranoid=0\n", strerror(errno));
    return 1;
  }
  ioctl(fd_cycles, PERF_EVENT_IOC_ID, &id_cycles);

  // 0xC9
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xC9;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev1 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev1 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev1 (0xC9) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev1, PERF_EVENT_IOC_ID, &id_ev1);

  // 0xCA
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xCA;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev2 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev2 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev2 (0xCA) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev2, PERF_EVENT_IOC_ID, &id_ev2);

  // 0xCB
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xCB;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev3 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev3 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev3 (0xCB) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev3, PERF_EVENT_IOC_ID, &id_ev3);

  // 0xCC
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xCC;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev4 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev4 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev4 (0xCC) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev4, PERF_EVENT_IOC_ID, &id_ev4);

  // 0xD0
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xD0;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev5 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev5 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev5 (0xD0) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev5, PERF_EVENT_IOC_ID, &id_ev5);

  // 0xD1
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xD1;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev6 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev6 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev6 (0xD1) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev6, PERF_EVENT_IOC_ID, &id_ev6);

  /* ---------- Inicializa o benchmark ---------- */
  countnegative_init();

  /* ---------- Inicia contadores ---------- */
  ioctl(fd_cycles, PERF_EVENT_IOC_RESET,  PERF_IOC_FLAG_GROUP);
  ioctl(fd_cycles, PERF_EVENT_IOC_ENABLE, PERF_IOC_FLAG_GROUP);

  /* ---------- Executa benchmark ---------- */
  countnegative_main();

  /* ---------- Para contadores ---------- */
  ioctl(fd_cycles, PERF_EVENT_IOC_DISABLE, PERF_IOC_FLAG_GROUP);

  /* ---------- Le resultados ---------- */
  read(fd_cycles, buf, sizeof(buf));
  for (i = 0; i < rf->nr; i++) {
    if      (rf->values[i].id == id_cycles) { val_cycles = rf->values[i].value; }
    else if (rf->values[i].id == id_ev1) { val_ev1 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev2) { val_ev2 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev3) { val_ev3 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev4) { val_ev4 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev5) { val_ev5 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev6) { val_ev6 = rf->values[i].value; }
  }

  save_data(val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6);

  /* ---------- Fecha descritores ---------- */
  close(fd_cycles);
  close(fd_ev1);
  close(fd_ev2);
  close(fd_ev3);
  close(fd_ev4);
  close(fd_ev5);
  close(fd_ev6);

  return 0;
}
