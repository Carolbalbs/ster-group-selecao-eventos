/*
  cubic benchmark com instrumentacao perf_event_open
  Grupo 7 de 10 - Eventos: CYCLES + 0xC3 + 0xC4 + 0xC5 + 0xC6 + 0xC7 + 0xC8
  Gerado automaticamente para captura dos 57 eventos PMU do ARM Cortex-A53
*/
#define _GNU_SOURCE
#include <sched.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <string.h>
#include <sys/ioctl.h>
#include <linux/perf_event.h>
#include <linux/hw_breakpoint.h>
#include <asm/unistd.h>
#include <errno.h>
#include <stdint.h>
#include <inttypes.h>
#include <time.h>
#include "wcclibm.h"
#include "snipmath.h"

/* ------------------------------------------------------------------ */
/*  Benchmark: cubic                                                   */
/* ------------------------------------------------------------------ */
float cubic_a1, cubic_b1, cubic_c1, cubic_d1;
float cubic_a2, cubic_b2, cubic_c2, cubic_d2;
float cubic_a3, cubic_b3, cubic_c3, cubic_d3;
float cubic_a4, cubic_b4, cubic_c4, cubic_d4;
float cubic_x[3];
float cubic_X, cubic_Y;
int cubic_solutions;
int cubic_checksum;

void cubic_solveCubic( float a, float b, float c, float d,
                       int *solutions, float *x ) {
  float a1 = b / a, a2 = c / a, a3 = d / a;
  float Q = ( a1 * a1 - 3.0f * a2 ) / 9.0f;
  float R = ( 2.0f * a1 * a1 * a1 - 9.0f * a1 * a2 + 27.0f * a3 ) / 54.0f;
  float R2_Q3 = R * R - Q * Q * Q;
  float theta;

  if ( R2_Q3 <= 0 ) {
    *solutions = 3;
    theta = basicmath___ieee754_acosf( R / basicmath___ieee754_sqrtf( Q * Q * Q ) );
    x[0] = -2.0f * basicmath___ieee754_sqrtf( Q ) * basicmath___cosf(
             theta / 3.0f ) - a1 / 3.0f;
    x[1] = -2.0f * basicmath___ieee754_sqrtf( Q ) * basicmath___cosf( (
             theta + 2.0f * PI ) / 3.0f ) - a1 / 3.0f;
    x[2] = -2.0f * basicmath___ieee754_sqrtf( Q ) * basicmath___cosf( (
             theta + 4.0f * PI ) / 3.0f ) - a1 / 3.0f;
  } else {
    *solutions = 1;
    x[0] = basicmath___ieee754_powf( basicmath___ieee754_sqrtf( R2_Q3 ) +
                                     basicmath___fabsf( R ), 1 / 3.0f );
    x[0] += Q / x[0];
    x[0] *= ( R < 0.0f ) ? 1 : -1;
    x[0] -= a1 / 3.0f;
  }
}

void cubic_init( void ) {
  cubic_a1 = 1.0f; cubic_b1 = -10.5f; cubic_c1 = 32.0f;  cubic_d1 = -30.0f;
  cubic_a2 = 1.0f; cubic_b2 =  -4.5f; cubic_c2 = 17.0f;  cubic_d2 = -30.0f;
  cubic_a3 = 1.0f; cubic_b3 =  -3.5f; cubic_c3 = 22.0f;  cubic_d3 = -31.0f;
  cubic_a4 = 1.0f; cubic_b4 = -13.7f; cubic_c4 =  1.0f;  cubic_d4 = -35.0f;
  cubic_X = 0; cubic_Y = 0;
  cubic_checksum = 0;
}

void cubic_main( void ) {
  cubic_solveCubic( cubic_a1, cubic_b1, cubic_c1, cubic_d1, &cubic_solutions, cubic_x );
  cubic_checksum += cubic_solutions;
  cubic_solveCubic( cubic_a2, cubic_b2, cubic_c2, cubic_d2, &cubic_solutions, cubic_x );
  cubic_checksum += cubic_solutions;
  cubic_solveCubic( cubic_a3, cubic_b3, cubic_c3, cubic_d3, &cubic_solutions, cubic_x );
  cubic_checksum += cubic_solutions;
  cubic_solveCubic( cubic_a4, cubic_b4, cubic_c4, cubic_d4, &cubic_solutions, cubic_x );
  cubic_checksum += cubic_solutions;

  for ( cubic_a1 = 1; cubic_a1 < 10; cubic_a1 += 2 )
    for ( cubic_b1 = 10; cubic_b1 > 0; cubic_b1 -= 2 )
      for ( cubic_c1 = 5; cubic_c1 < 15; cubic_c1 += 1.5f )
        for ( cubic_d1 = -1; cubic_d1 > -11; cubic_d1 -= 2 ) {
          cubic_solveCubic( cubic_a1, cubic_b1, cubic_c1, cubic_d1, &cubic_solutions, cubic_x );
          cubic_checksum += cubic_solutions;
        }
}

/* ------------------------------------------------------------------ */
/*  Estrutura de leitura do perf                                       */
/* ------------------------------------------------------------------ */
struct read_format {
  uint64_t nr;
  struct {
    uint64_t value;
    uint64_t id;
  } values[];
};

/* ------------------------------------------------------------------ */
/*  Salva resultado no CSV                                             */
/* ------------------------------------------------------------------ */
void save_data(uint64_t val_cycles, uint64_t val_ev1, uint64_t val_ev2,
               uint64_t val_ev3, uint64_t val_ev4, uint64_t val_ev5, uint64_t val_ev6) {
  FILE *arq = fopen("saida_cubic_n_eventos.csv", "a");
  if (arq == NULL) { printf("ERROR OPEN FILE\n"); return; }
  fprintf(arq, "%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 " \n",
          val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6);
  fclose(arq);
}

/* ------------------------------------------------------------------ */
/*  Main                                                               */
/* ------------------------------------------------------------------ */
int main(int argc, char* argv[]) {

  struct perf_event_attr pea;
  int fd_cycles, fd_ev1, fd_ev2, fd_ev3, fd_ev4, fd_ev5, fd_ev6;
  uint64_t id_cycles, id_ev1, id_ev2, id_ev3, id_ev4, id_ev5, id_ev6;
  uint64_t val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6;
  char buf[4096];
  struct read_format* rf = (struct read_format*) buf;
  int i;

  /* Fixa o processo no CPU 0 */
  cpu_set_t set;
  CPU_ZERO(&set);
  CPU_SET(0, &set);
  sched_setaffinity(getpid(), sizeof(set), &set);

  /* ---------- Abre contador de ciclos (grupo lider) ---------- */
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_HARDWARE;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = PERF_COUNT_HW_CPU_CYCLES;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_cycles = syscall(__NR_perf_event_open, &pea, 0, -1, -1, 0);
  if (fd_cycles == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_cycles falhou: %s\n"
                    "Verifique: sudo sysctl -w kernel.perf_event_paranoid=0\n", strerror(errno));
    return 1;
  }
  ioctl(fd_cycles, PERF_EVENT_IOC_ID, &id_cycles);

  // 0xC3
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xC3;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev1 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev1 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev1 (0xC3) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev1, PERF_EVENT_IOC_ID, &id_ev1);

  // 0xC4
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xC4;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev2 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev2 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev2 (0xC4) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev2, PERF_EVENT_IOC_ID, &id_ev2);

  // 0xC5
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xC5;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev3 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev3 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev3 (0xC5) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev3, PERF_EVENT_IOC_ID, &id_ev3);

  // 0xC6
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xC6;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev4 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev4 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev4 (0xC6) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev4, PERF_EVENT_IOC_ID, &id_ev4);

  // 0xC7
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xC7;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev5 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev5 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev5 (0xC7) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev5, PERF_EVENT_IOC_ID, &id_ev5);

  // 0xC8
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0xC8;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev6 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev6 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev6 (0xC8) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev6, PERF_EVENT_IOC_ID, &id_ev6);

  /* ---------- Inicializa o benchmark ---------- */
  cubic_init();

  /* ---------- Inicia contadores ---------- */
  ioctl(fd_cycles, PERF_EVENT_IOC_RESET,  PERF_IOC_FLAG_GROUP);
  ioctl(fd_cycles, PERF_EVENT_IOC_ENABLE, PERF_IOC_FLAG_GROUP);

  /* ---------- Executa benchmark ---------- */
  cubic_main();

  /* ---------- Para contadores ---------- */
  ioctl(fd_cycles, PERF_EVENT_IOC_DISABLE, PERF_IOC_FLAG_GROUP);

  /* ---------- Le resultados ---------- */
  read(fd_cycles, buf, sizeof(buf));
  for (i = 0; i < rf->nr; i++) {
    if      (rf->values[i].id == id_cycles) { val_cycles = rf->values[i].value; }
    else if (rf->values[i].id == id_ev1) { val_ev1 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev2) { val_ev2 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev3) { val_ev3 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev4) { val_ev4 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev5) { val_ev5 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev6) { val_ev6 = rf->values[i].value; }
  }

  save_data(val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6);

  /* ---------- Fecha descritores ---------- */
  close(fd_cycles);
  close(fd_ev1);
  close(fd_ev2);
  close(fd_ev3);
  close(fd_ev4);
  close(fd_ev5);
  close(fd_ev6);

  return 0;
}
