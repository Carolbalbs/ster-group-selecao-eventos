/*
  minver benchmark com instrumentacao perf_event_open
  Grupo 2 de 10 - Eventos: CYCLES + 0x06 + 0x07 + 0x08 + 0x09 + 0x0A + 0x0B
  Gerado automaticamente para captura dos 57 eventos PMU do ARM Cortex-A53
*/
#define _GNU_SOURCE
#include <sched.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <string.h>
#include <sys/ioctl.h>
#include <linux/perf_event.h>
#include <linux/hw_breakpoint.h>
#include <asm/unistd.h>
#include <errno.h>
#include <stdint.h>
#include <inttypes.h>
#include <time.h>

/* ================================================================== */
/*  Benchmark: minver (inline - sem headers externos)                 */
/* ================================================================== */
/*

    This program is part of the TACLeBench benchmark suite.
    Version V 1.x

    Name: minver

    Author: Sung-Soo Lim

    Function: Matrix inversion for 3x3 floating point matrix.

    Source: SNU-RT Benchmark Suite, via MRTC
           http://www.mrtc.mdh.se/projects/wcet/wcet_bench/minver/minver.c

    Changes: a brief summary of major functional changes (not formatting)

    License: may be used, modified, and re-distributed freely, but
             the SNU-RT Benchmark Suite must be acknowledged

*/

/*
    This program is derived from the SNU-RT Benchmark Suite for Worst
    Case Timing Analysis by Sung-Soo Lim

    Original source: Turbo C Programming for Engineering by Hyun Soo Ahn
*/

/*
    Forward declaration of functions
*/

int minver_minver( int side, double eps );
int minver_mmul( int row_a, int col_a, int row_b, int col_b );
double minver_fabs( double n );
void minver_init();
int minver_return();
void minver_main();
int main( void );

/*
    Declaration of global variables
*/

double  minver_a[ 3 ][ 3 ] = {
  {3.0, -6.0,  7.0},
  {9.0,  0.0, -5.0},
  {5.0, -8.0,  6.0},
};
double minver_b[ 3 ][ 3 ];
double minver_c[ 3 ][ 3 ];
double minver_aa[ 3 ][ 3 ];
double minver_a_i[ 3 ][ 3 ];
double minver_det;

/*
    Arithmetic math functions
*/


double minver_fabs( double n )
{
  double f;

  if ( n >= 0 )
    f = n;
  else
    f = -n;
  return f;
}


int  minver_mmul( int row_a, int col_a, int row_b, int col_b )
{
  int i, j, k, row_c, col_c;
  double w;

  row_c = row_a;
  col_c = col_b;

  if ( row_c < 1 || row_b < 1 || col_c < 1 || col_a != row_b )
    return ( 999 );

  _Pragma( "loopbound min 3 max 3" )
  for ( i = 0; i < row_c; i++ ) {
    _Pragma( "loopbound min 3 max 3" )
    for ( j = 0; j < col_c; j++ ) {
      w = 0.0;
      _Pragma( "loopbound min 3 max 3" )
      for ( k = 0; k < row_b; k++ )
        w += minver_a[ i ][ k ] * minver_b[ k ][ j ];

      minver_c[ i ][ j ] = w;

    }
  }
  return ( 0 );

}


int minver_minver( int side, double eps )
{

  int work[ 500 ], i, j, k, iw;
  int r = 0;
  double w = 0, wmax, pivot, api, w1;

  if ( side < 2 || side > 500 || eps <= 0.0 )
    return ( 999 );
  w1 = 1.0;
  _Pragma( "loopbound min 3 max 3" )
  for ( i = 0; i < side; i++ )
    work[ i ] = i;
  _Pragma( "loopbound min 3 max 3" )
  for ( k = 0; k < side; k++ ) {
    wmax = 0.0;
    _Pragma( "loopbound min 1 max 3" )
    for ( i = k; i < side; i++ ) {
      w = minver_fabs( minver_a[ i ][ k ] );
      if ( w > wmax ) {
        wmax = w;
        r = i;
      }
    }
    pivot = minver_a[ r ][ k ];
    api = minver_fabs( pivot );
    if ( api <= eps ) {
      minver_det = w1;
      return ( 1 );
    }
    w1 *= pivot;
    if ( r != k ) {
      w1 = -w;
      iw = work[ k ];
      work[ k ] = work[ r ];
      work[ r ] = iw;
      _Pragma( "loopbound min 3 max 3" )
      for ( j = 0; j < side; j++ ) {
        w = minver_a[ k ][ j ];
        minver_a[ k ][ j ] = minver_a[ r ][ j ];
        minver_a[ r ][ j ] = w;
      }
    }
    _Pragma( "loopbound min 3 max 3" )
    for ( i = 0; i < side; i++ )
      minver_a[ k ][ i ] /= pivot;
    _Pragma( "loopbound min 3 max 3" )
    for ( i = 0; i < side; i++ ) {
      if ( i != k ) {
        w = minver_a[ i ][ k ];
        if ( w != 0.0 ) {
          _Pragma( "loopbound min 3 max 3" )
          for ( j = 0; j < side; j++ ) {
            if ( j != k ) minver_a[ i ][ j ] -= w * minver_a[ k ][ j ];
          }
          minver_a[ i ][ k ] = -w / pivot;

        }
      }
    }
    minver_a[ k ][ k ] = 1.0 / pivot;
  }
  _Pragma( "loopbound min 3 max 3" )
  for ( i = 0; i < side; ) {
    _Pragma( "loopbound min 1 max 3" )
    while ( 1 ) {
      k = work[ i ];
      if ( k == i ) break;
      iw = work[ k ];
      work[ k ] = work[ i ];
      work[ i ] = iw;
      _Pragma( "loopbound min 3 max 3" )
      for ( j = 0; j < side; j++ ) {
        w = minver_a [k ][ i ];
        minver_a[ k ][ i ] = minver_a[ k ][ k ];
        minver_a[ k ][ k ] = w;
      }
    }
    i++;
  }
  minver_det = w1;
  return ( 0 );

}

/*
    Initialization- and return-value-related functions
*/

void minver_init()
{
  int i, j;
  volatile int x = 0;

  _Pragma( "loopbound min 3 max 3" )
  for ( i = 0; i < 3; i++ ) {
    _Pragma( "loopbound min 3 max 3" )
    for ( j = 0; j < 3; j++ )
      minver_a[ i ][ j ] += x;
  }
}


int minver_return()
{
  int i, j;
  double check_sum = 0;

  _Pragma( "loopbound min 3 max 3" )
  for ( i = 0; i < 3; i++ ) {
    _Pragma( "loopbound min 3 max 3" )
    for ( j = 0; j < 3; j++ )
      check_sum += minver_a_i[ i ][ j ];
  }
  /* Avoid double comparison */
  return ( int )( check_sum * 100 ) != 48;
}


/*
    Main functions
*/


void _Pragma( "entrypoint" ) minver_main()
{
  int i, j;
  double eps;
  eps = 1.0e-6;
  _Pragma( "loopbound min 3 max 3" )
  for ( i = 0; i < 3; i++ ) {
    _Pragma( "loopbound min 3 max 3" )
    for ( j = 0; j < 3; j++ )
      minver_aa[ i ][ j ] = minver_a[ i ][ j ];
  }

  minver_minver( 3, eps );
  _Pragma( "loopbound min 3 max 3" )
  for ( i = 0; i < 3; i++ ) {
    _Pragma( "loopbound min 3 max 3" )
    for ( j = 0; j < 3; j++ )
      minver_a_i[ i ][ j ] = minver_a[ i ][ j ];
  }

  minver_mmul( 3, 3, 3, 3 );
}

/* ================================================================== */
/*  Estrutura de leitura do perf                                       */
/* ================================================================== */
struct perf_read_format {
  uint64_t nr;
  struct {
    uint64_t value;
    uint64_t id;
  } values[];
};

/* ================================================================== */
/*  Salva resultado no CSV                                             */
/* ================================================================== */
void save_data(uint64_t val_cycles, uint64_t val_ev1, uint64_t val_ev2,
               uint64_t val_ev3, uint64_t val_ev4, uint64_t val_ev5, uint64_t val_ev6) {
  FILE *arq = fopen("saida_minver_n_eventos.csv", "a");
  if (arq == NULL) { printf("ERROR OPEN FILE\n"); return; }
  fprintf(arq, "%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 ";%" PRIu64 " \n",
          val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6);
  fclose(arq);
}

/* ================================================================== */
/*  Main                                                               */
/* ================================================================== */
int main(int argc, char* argv[]) {

  struct perf_event_attr pea;
  int fd_cycles, fd_ev1, fd_ev2, fd_ev3, fd_ev4, fd_ev5, fd_ev6;
  uint64_t id_cycles, id_ev1, id_ev2, id_ev3, id_ev4, id_ev5, id_ev6;
  uint64_t val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6;
  char buf[4096];
  struct perf_read_format* rf = (struct perf_read_format*) buf;
  int i;

  /* Fixa o processo no CPU 0 */
  cpu_set_t set;
  CPU_ZERO(&set);
  CPU_SET(0, &set);
  sched_setaffinity(getpid(), sizeof(set), &set);

  /* ---------- Abre contador de ciclos (grupo lider) ---------- */
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_HARDWARE;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = PERF_COUNT_HW_CPU_CYCLES;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_cycles = syscall(__NR_perf_event_open, &pea, 0, -1, -1, 0);
  if (fd_cycles == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_cycles falhou: %s\n"
                    "Verifique: sudo sysctl -w kernel.perf_event_paranoid=0\n", strerror(errno));
    return 1;
  }
  ioctl(fd_cycles, PERF_EVENT_IOC_ID, &id_cycles);

  // 0x06
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0x06;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev1 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev1 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev1 (0x06) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev1, PERF_EVENT_IOC_ID, &id_ev1);

  // 0x07
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0x07;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev2 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev2 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev2 (0x07) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev2, PERF_EVENT_IOC_ID, &id_ev2);

  // 0x08
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0x08;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev3 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev3 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev3 (0x08) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev3, PERF_EVENT_IOC_ID, &id_ev3);

  // 0x09
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0x09;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev4 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev4 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev4 (0x09) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev4, PERF_EVENT_IOC_ID, &id_ev4);

  // 0x0A
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0x0A;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev5 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev5 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev5 (0x0A) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev5, PERF_EVENT_IOC_ID, &id_ev5);

  // 0x0B
  memset(&pea, 0, sizeof(struct perf_event_attr));
  pea.type = PERF_TYPE_RAW;
  pea.size = sizeof(struct perf_event_attr);
  pea.config = 0x0B;
  pea.disabled = 1;
  pea.exclude_kernel = 1;
  pea.exclude_hv = 1;
  pea.read_format = PERF_FORMAT_GROUP | PERF_FORMAT_ID;
  fd_ev6 = syscall(__NR_perf_event_open, &pea, 0, -1, fd_cycles, 0);
  if (fd_ev6 == -1) {
    fprintf(stderr, "ERRO: perf_event_open fd_ev6 (0x0B) falhou: %s\n", strerror(errno));
    close(fd_cycles);
    return 1;
  }
  ioctl(fd_ev6, PERF_EVENT_IOC_ID, &id_ev6);

  /* ---------- Inicializa o benchmark ---------- */
  minver_init();

  /* ---------- Inicia contadores ---------- */
  ioctl(fd_cycles, PERF_EVENT_IOC_RESET,  PERF_IOC_FLAG_GROUP);
  ioctl(fd_cycles, PERF_EVENT_IOC_ENABLE, PERF_IOC_FLAG_GROUP);

  /* ---------- Executa benchmark ---------- */
  minver_main();

  /* ---------- Para contadores ---------- */
  ioctl(fd_cycles, PERF_EVENT_IOC_DISABLE, PERF_IOC_FLAG_GROUP);

  /* ---------- Le resultados ---------- */
  read(fd_cycles, buf, sizeof(buf));
  for (i = 0; i < rf->nr; i++) {
    if      (rf->values[i].id == id_cycles) { val_cycles = rf->values[i].value; }
    else if (rf->values[i].id == id_ev1) { val_ev1 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev2) { val_ev2 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev3) { val_ev3 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev4) { val_ev4 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev5) { val_ev5 = rf->values[i].value; }
    else if (rf->values[i].id == id_ev6) { val_ev6 = rf->values[i].value; }
  }

  save_data(val_cycles, val_ev1, val_ev2, val_ev3, val_ev4, val_ev5, val_ev6);

  /* ---------- Fecha descritores ---------- */
  close(fd_cycles);
  close(fd_ev1);
  close(fd_ev2);
  close(fd_ev3);
  close(fd_ev4);
  close(fd_ev5);
  close(fd_ev6);

  return 0;
}
