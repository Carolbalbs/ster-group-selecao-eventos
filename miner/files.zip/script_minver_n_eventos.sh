#!/bin/bash


TAMANHO=10000
VEZES=3

## listas com 10 parâmetros
arquivocsv=(
"saida_minver_n_eventos.csv"
"saida_minver_n_eventos.csv"
"saida_minver_n_eventos.csv"
"saida_minver_n_eventos.csv"
"saida_minver_n_eventos.csv"
"saida_minver_n_eventos.csv"
"saida_minver_n_eventos.csv"
"saida_minver_n_eventos.csv"
"saida_minver_n_eventos.csv"
"saida_minver_n_eventos.csv"
)

arquivoexe=(
"minver_n1_eventos"
"minver_n2_eventos"
"minver_n3_eventos"
"minver_n4_eventos"
"minver_n5_eventos"
"minver_n6_eventos"
"minver_n7_eventos"
"minver_n8_eventos"
"minver_n9_eventos"
"minver_n10_eventos"
)

novonomeCI=(
"minver_n1_eventos_"
"minver_n2_eventos_"
"minver_n3_eventos_"
"minver_n4_eventos_"
"minver_n5_eventos_"
"minver_n6_eventos_"
"minver_n7_eventos_"
"minver_n8_eventos_"
"minver_n9_eventos_"
"minver_n10_eventos_"
)

header=(
"CYCLES;0x00;0x01;0x02;0x03;0x04;0x05"
"CYCLES;0x06;0x07;0x08;0x09;0x0A;0x0B"
"CYCLES;0x0C;0x0D;0x0E;0x0F;0x10;0x12"
"CYCLES;0x13;0x14;0x15;0x16;0x17;0x18"
"CYCLES;0x19;0x1A;0x1D;0x1E;0x60;0x61"
"CYCLES;0x7A;0x86;0x87;0xC0;0xC1;0xC2"
"CYCLES;0xC3;0xC4;0xC5;0xC6;0xC7;0xC8"
"CYCLES;0xC9;0xCA;0xCB;0xCC;0xD0;0xD1"
"CYCLES;0xD2;0xE0;0xE1;0xE2;0xE3;0xE4"
"CYCLES;0xE5;0xE6;0xE7;0xE8;0xE0;0xE1"
)

TEXTO_CI="fim cnt n eventos"

for k in ${!arquivoexe[@]}
do
    csv=${arquivocsv[$k]}
    exe=${arquivoexe[$k]}
    prefix=${novonomeCI[$k]}
    head=${header[$k]}

    COUNT=0

    for j in $(seq 1 $VEZES)
    do
        rm -f "$csv"
	echo "$head" > "$csv"

        for i in $(seq 1 $TAMANHO)
        do
            ./$exe
        done

        COUNT=$((COUNT+1))
        nomecsv=${prefix}${COUNT}.csv

        mv "$csv" "$nomecsv"

	sleep 1

        echo $TEXTO_CI $k $COUNT
    done

done
